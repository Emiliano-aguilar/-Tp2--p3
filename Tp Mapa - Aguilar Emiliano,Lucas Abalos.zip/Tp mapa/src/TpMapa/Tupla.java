package TpMapa;

public class Tupla<k,j> {
	public k elem1;
	public j elem2;
	public Tupla(k e1, j e2) {
		elem1 = e1;
		elem2 = e2;
	}
	
	public k getX() {
		return elem1;
	}
	
	public void setelem1(k e1) {
		this.elem1= e1;
	}
	public j getY() {
		return elem2;
	}
	
	public void setelem2(j e2) {
		this.elem2= e2;
	}
	
	@Override
	public String toString() {
		return "[" + elem1 + ", " + elem2 + "]";
	}
	
	public boolean sonIguales(Tupla<k, j> otraTupla) {
		return this.elem1.equals(otraTupla.elem1) &&
				this.elem2.equals(otraTupla.elem2);
	}
	

	
}
