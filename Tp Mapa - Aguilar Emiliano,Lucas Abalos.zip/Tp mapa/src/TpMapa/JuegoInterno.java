package TpMapa;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class JuegoInterno {
private ArrayList<String> cordenadas;
private OutputStreamWriter out;
private FileOutputStream fos;
private ArrayList<Tupla<Double, Double>> cordenadassTupla;

public JuegoInterno() {
	cordenadas = new ArrayList<String>();
	cordenadassTupla = new ArrayList<Tupla<Double, Double>>();

}

public void leerArchivo() {
	File archivo = new File("Cordenadas.txt");
	try {
		FileInputStream fis = new FileInputStream(archivo);
		Scanner scanner = new Scanner(fis);
		while(scanner.hasNextLine()) {
			String linea = scanner.nextLine();
			cordenadas.add(linea);
		}
		scanner.close();
		pasarATupla(cordenadas);
		
	}catch(FileNotFoundException e){
		
	}
	
}


protected void pasarATupla(ArrayList<String> cordenadas) {
	 for (int i = 0; i < cordenadas.size(); i = i +2) { 
	  Tupla tupla = new Tupla<Double,Double>(convertirADecimal(cordenadas.get(i)) ,convertirADecimal(cordenadas.get(i+1))); 
	  cordenadassTupla.add(tupla); 
	 } 
}


public ArrayList<Tupla<Double, Double>> dameCordenadas() {	
	return (ArrayList<Tupla<Double, Double>>) cordenadassTupla.clone();
}

public Integer cantidadDeCordenadas() {
	return cordenadassTupla.size();
}


public Integer cantidadEntradasLeidas () {
	return cordenadas.size();
}

private Double convertirADecimal(String cords2) {
	Double newCord = Double.parseDouble(cords2);
	return newCord;
}

}
