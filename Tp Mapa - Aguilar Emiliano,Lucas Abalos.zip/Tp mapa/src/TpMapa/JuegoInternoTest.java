package TpMapa;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class JuegoInternoTest {

	@Before
	public void setUp() throws Exception {
	}

	
	
	
	
	@Test
	public void leerArchivoTest() {
		JuegoInterno nuevo = new JuegoInterno();
		nuevo.leerArchivo();
		Integer cantidadLeidas = nuevo.cantidadEntradasLeidas();
		assertTrue(cantidadLeidas.equals(136));
	}
	
	@Test
	public void cantidadDeTuplasTest() {
		JuegoInterno nuevo = new JuegoInterno();
		nuevo.leerArchivo();
		Integer cantidadTuplas = nuevo.cantidadDeCordenadas();
		assertTrue(cantidadTuplas.equals(136/2));
	}

	@Test 
	public void pasarATuplaTest() {
		JuegoInterno nuevo = new JuegoInterno();
		ArrayList<String> arr = new ArrayList<String>();
		arr.add("-32.564");
		arr.add("-54.342");
		nuevo.pasarATupla(arr);
		Tupla<Double, Double> tuplaAnalizar = new Tupla<Double, Double>(-32.564, -54.342);
		assertTrue( nuevo.dameCordenadas().get(0).sonIguales(tuplaAnalizar));
	}
}
