package TpMapa;

import java.awt.Color;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JFrame;

import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.JMapViewer;
import org.openstreetmap.gui.jmapviewer.MapMarkerDot;
import org.openstreetmap.gui.jmapviewer.MapPolygonImpl;
import org.openstreetmap.gui.jmapviewer.interfaces.MapMarker;
import org.openstreetmap.gui.jmapviewer.interfaces.MapPolygon;
import javax.swing.JPanel;

public class Principal {

	private static final String Cords = null;
	private JFrame frame;
	private JMapViewer mapa;
	private JPanel panelMapa;
	private JPanel paneControles;
	private ArrayList<Tupla<Double, Double>> cordenadas;
	private JuegoInterno nuevo;
	private MapMarker[] puntos;
	private HashMap<Tupla<Double, Double>, Double> distanciaAristas;
	private GrafoListaDeVecinos g;
	private ArrayList<HashSet<Integer>> aristasGrafos;
	private ArrayList<Coordinate> aristasADibujar = new ArrayList<Coordinate>();
	private ArrayList<Coordinate> aristasADibujar2 = new ArrayList<Coordinate>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("JMap");
		panelMapa = new JPanel();
		panelMapa.setBounds(10, 23, 311, 173);
		frame.getContentPane().add(panelMapa);
		paneControles = new JPanel();
		paneControles.setBounds(457, 11, 242, 446);
		paneControles.setLayout(null);
		mapa = new JMapViewer();
		mapa.setZoomControlsVisible(false);
		nuevo = new JuegoInterno();
		nuevo.leerArchivo();
		definirTamanio(nuevo.cantidadDeCordenadas());

		distanciaAristas = new HashMap<Tupla<Double, Double>, Double>();

		g = new GrafoListaDeVecinos(nuevo.cantidadDeCordenadas());

		// nos posicionamos en argentina, Buenos Aires, Malvinas Argentinas, UNGS

		Coordinate cordinate = new Coordinate(-34.557534555, -58.779464534);

		mapa.setDisplayPosition(cordinate, 12);
		cordenadas = nuevo.dameCordenadas();
		llenarGrafo(g);
		dibujamePuntos(cordenadas);
		panelMapa.add(mapa);

	}

	private void llenarGrafo(GrafoListaDeVecinos g) {
		Double min = 1000000.0;
		Double actual = null;
		boolean flag = false;
		Tupla<Double, Double> tuplaAuxFor1 = null;
		Tupla<Double, Double> tuplaAuxFor2 = null;
		ArrayList<Coordinate> a = new ArrayList<Coordinate>();
		ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>> aristas = new ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>>();
		ArrayList<Double> distanciaAristas = new ArrayList<Double>();
		Tupla<Tupla<Double, Double>, Tupla<Double, Double>> Vertice = null;
		//aristasADibujar.add(new Coordinate(cordenadas.get(0).getX(), cordenadas.get(0).getY()));
		GrafoListaDeVecinos grafoAux = new GrafoListaDeVecinos(nuevo.cantidadDeCordenadas());
		llenarGrafoAux(grafoAux);
		HashSet<Tupla<Double, Double>> conjuntoVerticesUtilizados = new HashSet<Tupla<Double, Double>>();
		conjuntoVerticesUtilizados.add(cordenadas.get(0));
		for (int i = 0; i < cordenadas.size(); i++) {

			for (Tupla<Double, Double> tupla : conjuntoVerticesUtilizados) {
				for (Tupla<Double, Double> tupla2 : cordenadas) {

					if (!tupla.sonIguales(tupla2)
							&& !g.existeArista(cordenadas.indexOf(tupla), cordenadas.indexOf(tupla2))
							&& !conjuntoVerticesUtilizados.contains(tupla2)) {
						if (!esVecinoDeVecino(conjuntoVerticesUtilizados, tupla2, g)) {
							actual = g.distanciaFinal(tupla, tupla2);
							if (actual < min) {
								min = actual;
								tuplaAuxFor1 = tupla;
								tuplaAuxFor2 = tupla2;
								flag = true;
							}
						}

					}

				} // cierra el tercer for

			} // cierra el segundo for

			if (flag) {
				g.agregarArista(cordenadas.indexOf(tuplaAuxFor1), cordenadas.indexOf(tuplaAuxFor2));
				Vertice = new Tupla<Tupla<Double, Double>, Tupla<Double, Double>>(tuplaAuxFor1, tuplaAuxFor2);
				
				aristas.add(Vertice);
				distanciaAristas.add(min);
				conjuntoVerticesUtilizados.add(tuplaAuxFor1);
				conjuntoVerticesUtilizados.add(tuplaAuxFor2);
				tuplaAuxFor1 = null;
				tuplaAuxFor2 = null;
				Vertice = null;
				flag = false;
				min = 1000000.0;
				actual = 0.0;

				reiniciarVariables(tuplaAuxFor1, tuplaAuxFor2, Vertice, flag, min, actual);
			}

		} // cierra el primer for

		double promedioAristas = 0.0;
		for (int i = 0; i < distanciaAristas.size(); i++) {
			promedioAristas = promedioAristas + distanciaAristas.get(i);
		}
		
		
		
		promedioAristas = promedioAristas / aristas.size();
		boolean flag2 = false;
		for (int i = 0; i < distanciaAristas.size(); i++) {
			if (aristas.get(i).getX().getX() > -34.53000322098951) {
				System.out.println("Entre");
				
				aristasADibujar2.add(new Coordinate(aristas.get(i).getY().getX(), aristas.get(i).getY().getY()));
				if (!flag2) {
					flag2 = true;
					aristasADibujar2.add(new Coordinate(aristas.get(i).getX().getX(), aristas.get(i).getX().getY()));
					
				}
				
			} else {
				System.out.println("No entre");
				aristasADibujar.add(new Coordinate(aristas.get(i).getY().getX(), aristas.get(i).getY().getY()));
			}
			
		}
		
		
		
		System.out.println("el largo del primero es  es: " + aristasADibujar2.size() + aristasADibujar2.toString()); 
		  System.out.println("el largo del segundo es es: " + aristasADibujar.size() + aristasADibujar.toString());
		MapPolygon poligono1 = new MapPolygonImpl(aristasADibujar2);
		MapPolygon poligono2 = new MapPolygonImpl(aristasADibujar);
		poligono1.getStyle().setColor(Color.RED);
		poligono2.getStyle().setColor(Color.GREEN);
		mapa.addMapPolygon(poligono1);
		mapa.addMapPolygon(poligono2);

	}

	private boolean esVecinoDeVecino(HashSet<Tupla<Double, Double>> conjuntoVerticesUtilizados,
			Tupla<Double, Double> tuplaAnalizar, GrafoListaDeVecinos grafo) {
		boolean flag = false;
		for (int i = 0; i < conjuntoVerticesUtilizados.size(); i++) {
			flag = flag || conjuntoVerticesUtilizados.contains(tuplaAnalizar);
		}

		return flag;
	}

	private GrafoListaDeVecinos llenarGrafoAux(GrafoListaDeVecinos grafoAux) {

		for (Tupla<Double, Double> tupla : cordenadas) { // A ---- B
			for (Tupla<Double, Double> tupla2 : cordenadas) { // B C D ===== 5 2da itenracion

				if (!tupla.sonIguales(tupla2)
						&& !grafoAux.existeArista(cordenadas.indexOf(tupla), cordenadas.indexOf(tupla2))) {
					grafoAux.agregarArista(cordenadas.indexOf(tupla), cordenadas.indexOf(tupla2));
				}
			}
		}

		return grafoAux;
	}

	private void definirTamanio(Integer cantCordenadas) {
		puntos = new MapMarker[cantCordenadas];
	}

	private void dibujamePuntos(ArrayList<Tupla<Double, Double>> cordenadas2) {

		for (int i = 0; i < cordenadas.size(); i++) {
			InicializarPuntos(cordenadas.get(i), i);
		}

	}

	private void InicializarPuntos(Tupla<Double, Double> cords, Integer pos) {
		MapMarker marker = new MapMarkerDot(cords.getX(), cords.getY());
		marker.getStyle().setBackColor(Color.RED);
		marker.getStyle().setColor(Color.BLACK);
		puntos[pos] = marker;
		mapa.addMapMarker(marker);

		marker = null;
	}

	private void reiniciarVariables(Tupla tupla, Tupla tupla2, Tupla tupla3, Boolean flag, Double min, Double actual) {
		tupla = null;
		tupla2 = null;
		tupla3 = null;
		flag = false;
		min = 1000000.0;
		actual = 0.0;

	}

}
